<?php
$servername = "localhost";
$user = "webDesign21";
$key = "Yv/sp*OrTXfqnrVz";
$dbName = "316project";

// Create connection
$conn = mysqli_connect($servername, $user, $key, $dbName);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";


$uid = mysqli_real_escape_string($conn, $_POST['uid']);
$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);

$sql = "INSERT INTO users (username, password) VALUES ('$uid', '$pwd');";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location: http://localhost/index.html"); 
