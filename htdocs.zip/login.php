<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: welcome.php");
    exit;
}

//connects to server
require_once "config.php";


$username = $password = "";
$username_err = $password_err = $login_err = "";

/*
if($_SERVER["REQUEST_METHOD"] == "POST"){
 // Check if username is empty
    if(empty(trim($_POST["uid"]))){
        $username_err = "Please enter username.";
    } else{
        $uid = trim($_POST["uid"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["pwd"]))){
        $password_err = "Please enter your password.";
    } else{
        $pwd = trim($_POST["pwd"]);
    }
  }
*/

$uid = $_POST["uid"];
$sql = "SELECT username, password FROM users WHERE username = $uid;";
$result = mysqli_query($conn, $sql);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
  while ($row = mysqli_fetch_assoc($result)){
    echo $row['username'] . "<br>";
 }
}
 else {
  echo 'error';
 }
